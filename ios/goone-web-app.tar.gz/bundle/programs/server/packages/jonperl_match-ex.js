(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;

/* Package-scope variables */
var MatchEx;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
// packages/jonperl:match-ex/match_ex.js                                                      //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                              //
MatchEx = {};                                                                                 // 1
                                                                                              // 2
var nullOrUndefined = function (val) {                                                        // 3
  return val === null || typeof(val) === 'undefined';                                         // 4
};                                                                                            // 5
                                                                                              // 6
MatchEx.AlphaNumeric = function (optional, allowSpaces) {                                     // 7
  return Match.Where(function (email) {                                                       // 8
    if (optional && nullOrUndefined(email)) return true;                                      // 9
                                                                                              // 10
    var alphaNumericRegex = /^[a-z0-9]+$/i, alphaNumericWithSpacesRegex = /^[a-z\d\-_\s]+$/i; // 11
    return allowSpaces ? alphaNumericWithSpacesRegex.test(email)                              // 12
      : alphaNumericRegex.test(email);                                                        // 13
  });                                                                                         // 14
};                                                                                            // 15
                                                                                              // 16
MatchEx.Date = function (optional, allowEmpty) {                                              // 17
  return Match.Where(function (date) {                                                        // 18
    if (allowEmpty && date === '') return true;                                               // 19
                                                                                              // 20
    if (optional && nullOrUndefined(date)) return true;                                       // 21
                                                                                              // 22
    var dateRegex = /\d{4}-\d{2}-\d{2}/; //2014-05-01                                         // 23
    return dateRegex.test(date);                                                              // 24
  });                                                                                         // 25
};                                                                                            // 26
                                                                                              // 27
MatchEx.Enum = function (enumObject, optional) {                                              // 28
  return MatchEx.OneOf(_.values(enumObject), optional);                                       // 29
};                                                                                            // 30
                                                                                              // 31
MatchEx.Email = function (optional) {                                                         // 32
  return Match.Where(function (email) {                                                       // 33
    if (optional && nullOrUndefined(email)) return true;                                      // 34
                                                                                              // 35
    var emailRegex = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}/igm;                             // 36
    return emailRegex.test(email);                                                            // 37
  });                                                                                         // 38
};                                                                                            // 39
                                                                                              // 40
MatchEx.OneOf = function (values, optional) {                                                 // 41
  return Match.Where(function (value) {                                                       // 42
    if (optional && nullOrUndefined(value)) return true;                                      // 43
                                                                                              // 44
    return _.contains(values, value);                                                         // 45
  });                                                                                         // 46
};                                                                                            // 47
                                                                                              // 48
MatchEx.Url = function (optional, ignoreProtocol) {                                           // 49
  return Match.Where(function (url) {                                                         // 50
    if (optional && nullOrUndefined(url)) return true;                                        // 51
    if (ignoreProtocol) url = 'http://' + url;                                                // 52
                                                                                              // 53
    var urlRegex = /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i;
    return urlRegex.test(url);                                                                // 55
  });                                                                                         // 56
};                                                                                            // 57
                                                                                              // 58
MatchEx.String = function (minChar, maxChar) {                                                // 59
  return Match.Where(function (str) {                                                         // 60
    if (typeof str !== 'string') return false;                                                // 61
                                                                                              // 62
    if (minChar && str.length < minChar) return false;                                        // 63
    if (maxChar && str.length > maxChar) return false;                                        // 64
                                                                                              // 65
    return true;                                                                              // 66
  });                                                                                         // 67
};                                                                                            // 68
////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jonperl:match-ex'] = {
  MatchEx: MatchEx
};

})();

//# sourceMappingURL=jonperl_match-ex.js.map
