(function () {

/* Imports */
var _ = Package.underscore._;
var DDP = Package.ddp.DDP;
var DDPServer = Package.ddp.DDPServer;
var Meteor = Package.meteor.Meteor;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var EasySearch;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/matteodem:easy-search/lib/easy-search-common.js                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
EasySearch = (function () {                                                                                       // 1
  'use strict';                                                                                                   // 2
                                                                                                                  // 3
  var Searchers,                                                                                                  // 4
    indexes = {/** @see defaultOptions */},                                                                       // 5
    defaultOptions = {                                                                                            // 6
      'format' : 'mongo',                                                                                         // 7
      'limit' : 10,                                                                                               // 8
      'use' : 'minimongo',                                                                                        // 9
      'sort' : function () {                                                                                      // 10
        return Searchers[this.use].defaultSort(this);                                                             // 11
      },                                                                                                          // 12
      'permission' : function () {                                                                                // 13
        return true;                                                                                              // 14
      },                                                                                                          // 15
      'changeResults' : function (results) {                                                                      // 16
        return results;                                                                                           // 17
      },                                                                                                          // 18
      /**                                                                                                         // 19
       * When using elastic-search it's the query object,                                                         // 20
       * while using with mongo-db it's the selector object.                                                      // 21
       *                                                                                                          // 22
       * @param {String} searchString                                                                             // 23
       * @return {Object}                                                                                         // 24
       */                                                                                                         // 25
      'query' : function (searchString) {                                                                         // 26
        return Searchers[this.use].defaultQuery(this, searchString);                                              // 27
      }                                                                                                           // 28
    };                                                                                                            // 29
                                                                                                                  // 30
  /**                                                                                                             // 31
   * Searchers which contain all engines which can be used to search content, until now:                          // 32
   *                                                                                                              // 33
   * minimongo (client): Client side collection for reactive search                                               // 34
   * elastic-search (server): Elastic search server to search with (fast)                                         // 35
   * mongo-db (server): MongoDB on the server to search (more convenient)                                         // 36
   *                                                                                                              // 37
   */                                                                                                             // 38
  Searchers = {};                                                                                                 // 39
                                                                                                                  // 40
  return {                                                                                                        // 41
    /**                                                                                                           // 42
     * Placeholder config method.                                                                                 // 43
     *                                                                                                            // 44
     * @param {object} newConfig                                                                                  // 45
     */                                                                                                           // 46
    'config' : function (newConfig) {                                                                             // 47
      return {};                                                                                                  // 48
    },                                                                                                            // 49
    /**                                                                                                           // 50
     * Create a search index.                                                                                     // 51
     *                                                                                                            // 52
     * @param {String} name                                                                                       // 53
     * @param {Object} options                                                                                    // 54
     */                                                                                                           // 55
    'createSearchIndex' : function (name, options) {                                                              // 56
      check(name, Match.OneOf(String, null));                                                                     // 57
      check(options, Object);                                                                                     // 58
                                                                                                                  // 59
      options.field = _.isArray(options.field) ? options.field : [options.field];                                 // 60
      indexes[name] = _.extend(_.clone(defaultOptions), options);                                                 // 61
                                                                                                                  // 62
      Searchers[options.use] &&  Searchers[options.use].createSearchIndex(name, options);                         // 63
    },                                                                                                            // 64
    /**                                                                                                           // 65
     * Perform a search.                                                                                          // 66
     *                                                                                                            // 67
     * @param {String} name             the search index                                                          // 68
     * @param {String} searchString     the string to be searched                                                 // 69
     * @param {Object} options          defined with createSearchIndex                                            // 70
     * @param {Function} callback       optional callback to be used                                              // 71
     */                                                                                                           // 72
    'search' : function (name, searchString, options, callback) {                                                 // 73
      var results,                                                                                                // 74
        index = indexes[name],                                                                                    // 75
        searcherType = index.use;                                                                                 // 76
                                                                                                                  // 77
      check(name, String);                                                                                        // 78
      check(searchString, String);                                                                                // 79
      check(options, Object);                                                                                     // 80
      check(callback, Match.Optional(Function));                                                                  // 81
                                                                                                                  // 82
      if ("undefined" === typeof Searchers[searcherType]) {                                                       // 83
        throw new Meteor.Error(500, "Couldnt search with the type: '" + searcherType + "'");                      // 84
      }                                                                                                           // 85
                                                                                                                  // 86
      // If custom permission check fails                                                                         // 87
      if (!index.permission(searchString)) {                                                                      // 88
        results = { 'results' : [], 'total' : 0 };                                                                // 89
      } else {                                                                                                    // 90
        results = Searchers[searcherType].search(name, searchString, _.extend(indexes[name], options), callback); // 91
      }                                                                                                           // 92
                                                                                                                  // 93
      return index.changeResults(results);                                                                        // 94
    },                                                                                                            // 95
    /**                                                                                                           // 96
     * Retrieve a specific index configuration.                                                                   // 97
     *                                                                                                            // 98
     * @param {String} name                                                                                       // 99
     * @return {Object}                                                                                           // 100
     * @api public                                                                                                // 101
     */                                                                                                           // 102
    'getIndex' : function (name) {                                                                                // 103
      return indexes[name];                                                                                       // 104
    },                                                                                                            // 105
    /**                                                                                                           // 106
     * Retrieve all index configurations                                                                          // 107
     */                                                                                                           // 108
    'getIndexes' : function () {                                                                                  // 109
      return indexes;                                                                                             // 110
    },                                                                                                            // 111
    /**                                                                                                           // 112
     * Retrieve a specific Seacher.                                                                               // 113
     *                                                                                                            // 114
     * @param {String} name                                                                                       // 115
     * @return {Object}                                                                                           // 116
     * @api public                                                                                                // 117
     */                                                                                                           // 118
    'getSearcher' : function (name) {                                                                             // 119
      return Searchers[name];                                                                                     // 120
    },                                                                                                            // 121
    /**                                                                                                           // 122
     * Retrieve all Searchers                                                                                     // 123
     */                                                                                                           // 124
    'getSearchers' : function () {                                                                                // 125
      return Searchers;                                                                                           // 126
    },                                                                                                            // 127
    /**                                                                                                           // 128
     * Makes it possible to override or extend the different                                                      // 129
     * types of search to use with EasySearch (the "use" property)                                                // 130
     * when using EasySearch.createSearchIndex()                                                                  // 131
     *                                                                                                            // 132
     * @param {String} key      Type, e.g. mongo-db, elastic-search                                               // 133
     * @param {Object} methods  Methods to be used, only 2 are required:                                          // 134
     *                          - createSearchIndex (name, options)                                               // 135
     *                          - search (name, searchString, [options, callback])                                // 136
     *                          - defaultQuery (options, searchString)                                            // 137
     *                          - defaultSort (options)                                                           // 138
     */                                                                                                           // 139
    'createSearcher' : function (key, methods) {                                                                  // 140
      check(key, String);                                                                                         // 141
      check(methods.search, Function);                                                                            // 142
      check(methods.createSearchIndex, Function);                                                                 // 143
      check(methods.defaultQuery, Function);                                                                      // 144
      check(methods.defaultSort, Function);                                                                       // 145
                                                                                                                  // 146
      Searchers[key] = methods;                                                                                   // 147
    }                                                                                                             // 148
  };                                                                                                              // 149
})();                                                                                                             // 150
                                                                                                                  // 151
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/matteodem:easy-search/lib/easy-search-convenience.js                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.Collection.prototype.initEasySearch = function (fields, options) {                                         // 1
  if (!_.isObject(options)) {                                                                                     // 2
    options = {};                                                                                                 // 3
  }                                                                                                               // 4
                                                                                                                  // 5
  EasySearch.createSearchIndex(this._name, _.extend(options, {                                                    // 6
    'collection' : this,                                                                                          // 7
    'field' : fields                                                                                              // 8
  }));                                                                                                            // 9
};                                                                                                                // 10
                                                                                                                  // 11
if (Meteor.isClient) {                                                                                            // 12
  jQuery.fn.esAutosuggestData = function () {                                                                     // 13
    var id,                                                                                                       // 14
      input = $(this);                                                                                            // 15
                                                                                                                  // 16
    if (input.prop("tagName") !== 'INPUT') {                                                                      // 17
      return [];                                                                                                  // 18
    }                                                                                                             // 19
                                                                                                                  // 20
    id = EasySearch.Components.generateId(input.parent().data('index'), input.parent().data('id'));               // 21
                                                                                                                  // 22
    return EasySearch.Components.Variables.get(id, 'autosuggestSelected');                                        // 23
  }                                                                                                               // 24
}                                                                                                                 // 25
                                                                                                                  // 26
                                                                                                                  // 27
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/matteodem:easy-search/lib/easy-search-server.js                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
'use strict';                                                                                                     // 1
var ElasticSearch = Npm.require('elasticsearch');                                                                 // 2
                                                                                                                  // 3
EasySearch._esDefaultConfig = {                                                                                   // 4
  host : 'localhost:9200'                                                                                         // 5
};                                                                                                                // 6
                                                                                                                  // 7
/**                                                                                                               // 8
 * Override the config for Elastic Search.                                                                        // 9
 *                                                                                                                // 10
 * @param {object} newConfig                                                                                      // 11
 */                                                                                                               // 12
EasySearch.config = function (newConfig) {                                                                        // 13
  if ("undefined" !== typeof newConfig) {                                                                         // 14
    check(newConfig, Object);                                                                                     // 15
    this._config = _.extend(this._esDefaultConfig, newConfig);                                                    // 16
    this.ElasticSearchClient = new ElasticSearch.Client(this._config);                                            // 17
  }                                                                                                               // 18
                                                                                                                  // 19
  return this._config;                                                                                            // 20
};                                                                                                                // 21
                                                                                                                  // 22
/**                                                                                                               // 23
 * Get the ElasticSearchClient                                                                                    // 24
 * @see http://www.elasticsearch.org/guide/en/elasticsearch/client/javascript-api/current                         // 25
 *                                                                                                                // 26
 * @return {ElasticSearch.Client}                                                                                 // 27
 */                                                                                                               // 28
EasySearch.getElasticSearchClient = function () {                                                                 // 29
  return this.ElasticSearchClient;                                                                                // 30
};                                                                                                                // 31
                                                                                                                  // 32
Meteor.methods({                                                                                                  // 33
  /**                                                                                                             // 34
   * Make server side search possible on the client.                                                              // 35
   *                                                                                                              // 36
   * @param {String} name                                                                                         // 37
   * @param {String} searchString                                                                                 // 38
   * @param {Object} options                                                                                      // 39
   */                                                                                                             // 40
  easySearch: function (name, searchString, options) {                                                            // 41
    check(name, String);                                                                                          // 42
    check(searchString, String);                                                                                  // 43
    check(options, Object);                                                                                       // 44
    return EasySearch.search(name, searchString, options);                                                        // 45
  }                                                                                                               // 46
});                                                                                                               // 47
                                                                                                                  // 48
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/matteodem:easy-search/lib/searchers/mongo.js                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
'use strict';                                                                                                     // 1
var methods = {                                                                                                   // 2
  /**                                                                                                             // 3
   * Set up a search index.                                                                                       // 4
   *                                                                                                              // 5
   * @param name                                                                                                  // 6
   * @param options                                                                                               // 7
   * @returns {void}                                                                                              // 8
   */                                                                                                             // 9
  'createSearchIndex' : function (name, options) {},                                                              // 10
  /**                                                                                                             // 11
   *                                                                                                              // 12
   * Perform a really simple search with mongo db.                                                                // 13
   *                                                                                                              // 14
   * @param {String} name                                                                                         // 15
   * @param {String} searchString                                                                                 // 16
   * @param {Object} options                                                                                      // 17
   * @param {Function} callback                                                                                   // 18
   * @returns {Array}                                                                                             // 19
   */                                                                                                             // 20
  'search' : function (name, searchString, options, callback) {                                                   // 21
    var cursor,                                                                                                   // 22
      results,                                                                                                    // 23
      selector,                                                                                                   // 24
      cursorOptions,                                                                                              // 25
      index = EasySearch.getIndex(name);                                                                          // 26
                                                                                                                  // 27
    if (!_.isObject(index)) {                                                                                     // 28
      return;                                                                                                     // 29
    }                                                                                                             // 30
                                                                                                                  // 31
    options.limit = options.limit || 10;                                                                          // 32
                                                                                                                  // 33
    // if several, fields do an $or search, otherwise only over the field                                         // 34
    selector = index.query(searchString);                                                                         // 35
                                                                                                                  // 36
    cursorOptions = {                                                                                             // 37
      sort : index.sort(searchString)                                                                             // 38
    };                                                                                                            // 39
                                                                                                                  // 40
    if (options.returnFields) {                                                                                   // 41
      cursorOptions.fields = options.returnFields;                                                                // 42
    }                                                                                                             // 43
                                                                                                                  // 44
    cursor = index.collection.find(selector, cursorOptions);                                                      // 45
                                                                                                                  // 46
    results = {                                                                                                   // 47
      'results' : _.first(cursor.fetch(), options.limit),                                                         // 48
      'total' : cursor.count()                                                                                    // 49
    };                                                                                                            // 50
                                                                                                                  // 51
    if (_.isFunction(callback)) {                                                                                 // 52
      callback(results);                                                                                          // 53
    }                                                                                                             // 54
                                                                                                                  // 55
    return results;                                                                                               // 56
  },                                                                                                              // 57
  /**                                                                                                             // 58
   * The default mongo-db query - selector used for searching.                                                    // 59
   *                                                                                                              // 60
   * @param {Object} options                                                                                      // 61
   * @param {String} searchString                                                                                 // 62
   * @returns {Object}                                                                                            // 63
   */                                                                                                             // 64
  'defaultQuery' : function (options, searchString) {                                                             // 65
    var orSelector,                                                                                               // 66
      selector = {},                                                                                              // 67
      field = options.field,                                                                                      // 68
      stringSelector = { '$regex' : '.*' + searchString + '.*', '$options' : 'i' };                               // 69
                                                                                                                  // 70
    if (_.isString(field)) {                                                                                      // 71
      selector[field] = stringSelector;                                                                           // 72
      return selector;                                                                                            // 73
    }                                                                                                             // 74
                                                                                                                  // 75
    // Convert numbers if configured                                                                              // 76
    if (options.convertNumbers && parseInt(searchString, 10) == searchString) {                                   // 77
      searchString = parseInt(searchString, 10);                                                                  // 78
    }                                                                                                             // 79
                                                                                                                  // 80
    // Should be an array                                                                                         // 81
    selector['$or'] = [];                                                                                         // 82
                                                                                                                  // 83
    _.each(field, function (fieldString) {                                                                        // 84
      orSelector = {};                                                                                            // 85
                                                                                                                  // 86
      if (_.isString(searchString)) {                                                                             // 87
        orSelector[fieldString] = stringSelector;                                                                 // 88
      } else if (_.isNumber(searchString)) {                                                                      // 89
        orSelector[fieldString] = searchString;                                                                   // 90
      }                                                                                                           // 91
                                                                                                                  // 92
      selector['$or'].push(orSelector);                                                                           // 93
    });                                                                                                           // 94
                                                                                                                  // 95
    return selector;                                                                                              // 96
  },                                                                                                              // 97
  /**                                                                                                             // 98
   * The default mongo-db sorting method used for sorting the results.                                            // 99
   *                                                                                                              // 100
   * @param {Object} options                                                                                      // 101
   * @return array                                                                                                // 102
   */                                                                                                             // 103
  'defaultSort' : function (options) {                                                                            // 104
    return options.field;                                                                                         // 105
  }                                                                                                               // 106
};                                                                                                                // 107
                                                                                                                  // 108
// Isomorphic Code FTW!                                                                                           // 109
if (Meteor.isServer) {                                                                                            // 110
  EasySearch.createSearcher('mongo-db', methods);                                                                 // 111
} else if (Meteor.isClient) {                                                                                     // 112
  EasySearch.createSearcher('minimongo', methods);                                                                // 113
}                                                                                                                 // 114
                                                                                                                  // 115
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/matteodem:easy-search/lib/searchers/elastic-search.js                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
'use strict';                                                                                                     // 1
                                                                                                                  // 2
var Future = Npm.require('fibers/future'),                                                                        // 3
  ElasticSearch = Npm.require('elasticsearch');                                                                   // 4
                                                                                                                  // 5
/**                                                                                                               // 6
 * Return Elastic Search indexable data.                                                                          // 7
 *                                                                                                                // 8
 * @param {Object} doc the document to get the values from                                                        // 9
 * @return {Object}                                                                                               // 10
 */                                                                                                               // 11
function getESFields(doc) {                                                                                       // 12
  var newDoc = {};                                                                                                // 13
                                                                                                                  // 14
  _.each(doc, function (value, key) {                                                                             // 15
    newDoc[key] = "string" === typeof value ? value : JSON.stringify(value);                                      // 16
  });                                                                                                             // 17
                                                                                                                  // 18
  return newDoc;                                                                                                  // 19
}                                                                                                                 // 20
                                                                                                                  // 21
EasySearch.createSearcher('elastic-search', {                                                                     // 22
  /**                                                                                                             // 23
   * Write a document to a specified index.                                                                       // 24
   *                                                                                                              // 25
   * @param {String} name                                                                                         // 26
   * @param {Object} doc                                                                                          // 27
   * @param {String} id                                                                                           // 28
   */                                                                                                             // 29
  'writeToIndex' : function (name, doc, id) {                                                                     // 30
    var config = EasySearch.config() || {};                                                                       // 31
                                                                                                                  // 32
    // add to index                                                                                               // 33
    EasySearch.ElasticSearchClient.index({                                                                        // 34
      index : name,                                                                                               // 35
      type : 'default',                                                                                           // 36
      id : id,                                                                                                    // 37
      body : doc                                                                                                  // 38
    }, function (err, data) {                                                                                     // 39
      if (err) {                                                                                                  // 40
        console.log('Had error adding a document!');                                                              // 41
        console.log(err);                                                                                         // 42
      }                                                                                                           // 43
                                                                                                                  // 44
      if (config.debug && console) {                                                                              // 45
        console.log('EasySearch: Added / Replaced document to Elastic Search:');                                  // 46
        console.log('EasySearch: ' + data + "\n");                                                                // 47
      }                                                                                                           // 48
    });                                                                                                           // 49
  },                                                                                                              // 50
  /**                                                                                                             // 51
   * Setup some observers on the mongo db collection provided.                                                    // 52
   *                                                                                                              // 53
   * @param {String} name                                                                                         // 54
   * @param {Object} options                                                                                      // 55
   */                                                                                                             // 56
  'createSearchIndex' : function (name, options) {                                                                // 57
    var searcherScope = this,                                                                                     // 58
      config = EasySearch.config() || {};                                                                         // 59
                                                                                                                  // 60
    if ("undefined" === typeof EasySearch.ElasticSearchClient) {                                                  // 61
      EasySearch.ElasticSearchClient = new ElasticSearch.Client(this._esDefaultConfig);                           // 62
    }                                                                                                             // 63
                                                                                                                  // 64
    options.collection.find().observeChanges({                                                                    // 65
      added: function (id, fields) {                                                                              // 66
        searcherScope.writeToIndex(name, getESFields(fields), id);                                                // 67
      },                                                                                                          // 68
      changed: function (id, fields) {                                                                            // 69
        // Overwrites the current document with the new doc                                                       // 70
        searcherScope.writeToIndex(name, getESFields(options.collection.findOne(id)), id);                        // 71
      },                                                                                                          // 72
      removed: function (id) {                                                                                    // 73
        EasySearch.ElasticSearchClient.delete({                                                                   // 74
          index: name,                                                                                            // 75
          type: 'default',                                                                                        // 76
          id: id                                                                                                  // 77
        }, function (error, response) {                                                                           // 78
          if (config.debug) {                                                                                     // 79
            console.log('Removed document with id ( ' +  id + ' )!');                                             // 80
          }                                                                                                       // 81
        });                                                                                                       // 82
      }                                                                                                           // 83
    });                                                                                                           // 84
  },                                                                                                              // 85
  /**                                                                                                             // 86
   * Get the data out of the JSON elastic search response.                                                        // 87
   *                                                                                                              // 88
   * @param {Object} data                                                                                         // 89
   * @returns {Array}                                                                                             // 90
   */                                                                                                             // 91
  'extractJSONData' : function (data) {                                                                           // 92
    data = _.isString(data) ? JSON.parse(data) : data;                                                            // 93
                                                                                                                  // 94
    var results = _.map(data.hits.hits, function (resultSet) {                                                    // 95
      var field = '_source';                                                                                      // 96
                                                                                                                  // 97
      if (resultSet['fields']) {                                                                                  // 98
        field = 'fields';                                                                                         // 99
      }                                                                                                           // 100
                                                                                                                  // 101
      resultSet[field]['_id'] = resultSet['_id'];                                                                 // 102
      return resultSet[field];                                                                                    // 103
    });                                                                                                           // 104
                                                                                                                  // 105
    return {                                                                                                      // 106
      'results' : results,                                                                                        // 107
      'total' : data.hits.total                                                                                   // 108
    };                                                                                                            // 109
  },                                                                                                              // 110
  /**                                                                                                             // 111
   * Perform a search with Elastic Search, using fibers.                                                          // 112
   *                                                                                                              // 113
   * @param {String} name                                                                                         // 114
   * @param {String} searchString                                                                                 // 115
   * @param {Object} options                                                                                      // 116
   * @param {Function} callback                                                                                   // 117
   * @returns {*}                                                                                                 // 118
   */                                                                                                             // 119
  'search' : function (name, searchString, options, callback) {                                                   // 120
    var bodyObj,                                                                                                  // 121
      that = this,                                                                                                // 122
      fut = new Future(),                                                                                         // 123
      index = EasySearch.getIndex(name);                                                                          // 124
                                                                                                                  // 125
    if (!_.isObject(index)) {                                                                                     // 126
      return;                                                                                                     // 127
    }                                                                                                             // 128
                                                                                                                  // 129
    bodyObj = {                                                                                                   // 130
      "query" : index.query(searchString),                                                                        // 131
      "sort" : index.sort(searchString),                                                                          // 132
      "size" : options.limit                                                                                      // 133
    };                                                                                                            // 134
                                                                                                                  // 135
    if (options.returnFields) {                                                                                   // 136
      if (options.returnFields.indexOf('_id') === -1 ) {                                                          // 137
        options.returnFields.push('_id');                                                                         // 138
      }                                                                                                           // 139
                                                                                                                  // 140
      bodyObj.fields = options.returnFields;                                                                      // 141
    }                                                                                                             // 142
                                                                                                                  // 143
    // Modify Elastic Search body if wished                                                                       // 144
    if (index.body && _.isFunction(index.body)) {                                                                 // 145
      bodyObj = index.body(bodyObj);                                                                              // 146
    }                                                                                                             // 147
                                                                                                                  // 148
    if ("function" === typeof callback) {                                                                         // 149
      EasySearch.ElasticSearchClient.search(name, bodyObj, callback);                                             // 150
      return;                                                                                                     // 151
    }                                                                                                             // 152
                                                                                                                  // 153
    // Most likely client call, return data set                                                                   // 154
    EasySearch.ElasticSearchClient.search({                                                                       // 155
      index : name,                                                                                               // 156
      body : bodyObj                                                                                              // 157
    }, function (error, data) {                                                                                   // 158
      if (error) {                                                                                                // 159
        console.log('Had an error while searching!');                                                             // 160
        console.log(error);                                                                                       // 161
        return;                                                                                                   // 162
      }                                                                                                           // 163
                                                                                                                  // 164
      if ("raw" !== index.format) {                                                                               // 165
        data = that.extractJSONData(data);                                                                        // 166
      }                                                                                                           // 167
                                                                                                                  // 168
      fut['return'](data);                                                                                        // 169
    });                                                                                                           // 170
                                                                                                                  // 171
    return fut.wait();                                                                                            // 172
  },                                                                                                              // 173
  /**                                                                                                             // 174
   * The default ES query object used for searching the results.                                                  // 175
   *                                                                                                              // 176
   * @param {Object} options                                                                                      // 177
   * @param {String} searchString                                                                                 // 178
   * @return array                                                                                                // 179
   */                                                                                                             // 180
  'defaultQuery' : function (options, searchString) {                                                             // 181
    return {                                                                                                      // 182
      "fuzzy_like_this" : {                                                                                       // 183
        "fields" : options.field,                                                                                 // 184
        "like_text" : searchString                                                                                // 185
      }                                                                                                           // 186
    };                                                                                                            // 187
  },                                                                                                              // 188
  /**                                                                                                             // 189
   * The default ES sorting method used for sorting the results.                                                  // 190
   *                                                                                                              // 191
   * @param {Object} options                                                                                      // 192
   * @return array                                                                                                // 193
   */                                                                                                             // 194
  'defaultSort' : function (options) {                                                                            // 195
    return options.field;                                                                                         // 196
  }                                                                                                               // 197
});                                                                                                               // 198
                                                                                                                  // 199
// Expose ElasticSearch API                                                                                       // 200
EasySearch.ElasticSearch = ElasticSearch;                                                                         // 201
                                                                                                                  // 202
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['matteodem:easy-search'] = {
  EasySearch: EasySearch
};

})();

//# sourceMappingURL=matteodem_easy-search.js.map
