(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['not-found'] = {};

})();

//# sourceMappingURL=not-found.js.map
