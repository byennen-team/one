(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.dashboard = {};

})();

//# sourceMappingURL=dashboard.js.map
