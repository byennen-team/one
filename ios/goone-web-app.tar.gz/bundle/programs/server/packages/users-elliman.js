(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Accounts = Package['accounts-base'].Accounts;
var check = Package.check.check;
var Match = Package.check.Match;
var MatchEx = Package['jonperl:match-ex'].MatchEx;

/* Package-scope variables */
var User;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/users-elliman/user_common.js                                                                //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
User = {};                                                                                              // 1
                                                                                                        // 2
User.model = {                                                                                          // 3
  // _id is optional because it might not be created yet                                                // 4
  _id: Match.Optional(String),                                                                          // 5
  emails: Match.Optional([                                                                              // 6
    {                                                                                                   // 7
      address: MatchEx.Email(),                                                                         // 8
      verified: Boolean                                                                                 // 9
    }                                                                                                   // 10
  ]),                                                                                                   // 11
  services: {                                                                                           // 12
    elliman: Match.Optional({                                                                           // 13
      id: Number,                                                                                       // 14
      firstName: String,                                                                                // 15
      lastName: String,                                                                                 // 16
      location: {                                                                                       // 17
        cityId: Number,                                                                                 // 18
        stateId: Number,                                                                                // 19
        zipCode: Number                                                                                 // 20
      },                                                                                                // 21
      numbers: {                                                                                        // 22
        fax:  Match.Optional(Number),                                                                   // 23
        mobile: Match.Optional(Number),                                                                 // 24
        phone: Match.Optional(Number),                                                                  // 25
        phoneExtension: Match.Optional(Number)                                                          // 26
      },                                                                                                // 27
      officeId: Number,                                                                                 // 28
      photoUrl: Match.Optional(MatchEx.Url()),                                                          // 29
      title: String                                                                                     // 30
    })                                                                                                  // 31
  }                                                                                                     // 32
};                                                                                                      // 33
                                                                                                        // 34
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/users-elliman/populate_agents.js                                                            //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
var userFromEllimanRow = function (row) {                                                               // 1
  var elliman = {                                                                                       // 2
    id: row.ID,                                                                                         // 3
    firstName: row.FIRST_NAME,                                                                          // 4
    lastName: row.LAST_NAME,                                                                            // 5
    location: {                                                                                         // 6
      cityId: row.CITY_ID,                                                                              // 7
      stateId: row.STATE_ID,                                                                            // 8
      zipCode: row.US_ZIP_CODE_ID                                                                       // 9
    },                                                                                                  // 10
    numbers: {},                                                                                        // 11
    officeId: row.OFFICE_ID,                                                                            // 12
    title: row.TITLE                                                                                    // 13
  };                                                                                                    // 14
                                                                                                        // 15
  if (row.PHONE_NUMBER) elliman.numbers.phone = row.PHONE_NUMBER;                                       // 16
  if (row.PHONE_EXTENSION) elliman.numbers.phoneExtension = row.PHONE_EXTENSION;                        // 17
  if (row.FAX_NUMBER) elliman.numbers.fax = row.FAX_NUMBER;                                             // 18
  if (row.MOBILE) elliman.numbers.mobile = row.MOBILE;                                                  // 19
                                                                                                        // 20
  if (row.PHOTO_URL) elliman.photoUrl = row.PHOTO_URL;                                                  // 21
                                                                                                        // 22
  var emails = [];                                                                                      // 23
                                                                                                        // 24
  if (row.EM_ADDRESS && Match.test(row.EM_ADDRESS, MatchEx.Email())) {                                  // 25
    // Figure out how to handle duplicates before inserting emails                                      // 26
//    emails.push({                                                                                     // 27
//      address: row.EM_ADDRESS,                                                                        // 28
//      verified: true                                                                                  // 29
//    });                                                                                               // 30
  }                                                                                                     // 31
                                                                                                        // 32
  var user = {                                                                                          // 33
    emails: emails,                                                                                     // 34
    services: {                                                                                         // 35
      elliman: elliman                                                                                  // 36
    }                                                                                                   // 37
  };                                                                                                    // 38
                                                                                                        // 39
  // Throw and log errors on users that do not match the model                                          // 40
  try {                                                                                                 // 41
    check(user, User.model);                                                                            // 42
  } catch (ex) {                                                                                        // 43
    // log the user with the issue                                                                      // 44
    console.log('Issue with', JSON.stringify(user));                                                    // 45
    throw ex;                                                                                           // 46
  }                                                                                                     // 47
                                                                                                        // 48
  return user;                                                                                          // 49
};                                                                                                      // 50
                                                                                                        // 51
// Populate the users collection with elliman agents.                                                   // 52
Meteor.startup(function () {                                                                            // 53
  var numUsers = Meteor.users.find().count();                                                           // 54
  console.log('Total Users', numUsers);                                                                 // 55
  if (numUsers > 0) return;                                                                             // 56
                                                                                                        // 57
  var ellimanAgents = JSON.parse(Assets.getText('elliman_agents_production.json'));                     // 58
  _.each(ellimanAgents, function (row) {                                                                // 59
    var user = userFromEllimanRow(row);                                                                 // 60
    Meteor.users.insert(user);                                                                          // 61
  });                                                                                                   // 62
                                                                                                        // 63
  console.log('Inserted', ellimanAgents.length, 'elliman agents');                                      // 64
});                                                                                                     // 65
                                                                                                        // 66
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/users-elliman/user_server.js                                                                //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
Meteor.users._ensureIndex({ 'services.elliman.id': 1}, { unique: true });                               // 1
                                                                                                        // 2
/**                                                                                                     // 3
 * Publish the current user.                                                                            // 4
 */                                                                                                     // 5
Meteor.publish('user', function () {                                                                    // 6
  if (! this.userId) return [];                                                                         // 7
  //                                                                                                    // 8
  // // TODO cut down what fields we publish                                                            // 9
  return Meteor.users.find(this.userId);                                                                // 10
                                                                                                        // 11
  // not seeing this?                                                                                   // 12
  console.log(User.services.elliman.firstName);                                                         // 13
});                                                                                                     // 14
                                                                                                        // 15
Meteor.methods({                                                                                        // 16
  /**                                                                                                   // 17
   * Setup a custom login method for elliman.                                                           // 18
   */                                                                                                   // 19
  loginWithElliman: function (agentId) {                                                                // 20
    var self = this;                                                                                    // 21
                                                                                                        // 22
    check(agentId, Number);                                                                             // 23
                                                                                                        // 24
    var currentUser = Meteor.users.findOne(self.userId);                                                // 25
                                                                                                        // 26
    return Accounts._loginMethod(this, 'loginWithElliman', arguments, 'loginWithElliman', function () { // 27
                                                                                                        // 28
      var user = Meteor.users.findOne({                                                                 // 29
        'services.elliman.id': agentId                                                                  // 30
      });                                                                                               // 31
                                                                                                        // 32
      if (! user) throw new Meteor.Error('User not found');                                             // 33
                                                                                                        // 34
      // Log the current user out.                                                                      // 35
      currentUser && Accounts._setLoginToken(currentUser._id, self.connection, null);                   // 36
                                                                                                        // 37
      return { userId: user._id };                                                                      // 38
    });                                                                                                 // 39
  }                                                                                                     // 40
});                                                                                                     // 41
                                                                                                        // 42
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['users-elliman'] = {
  User: User
};

})();

//# sourceMappingURL=users-elliman.js.map
