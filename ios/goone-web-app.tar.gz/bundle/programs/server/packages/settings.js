(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Settings;

(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/settings/settings.js                                                 //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
//Settings = {};                                                                 // 1
//                                                                               // 2
//Settings.isDevelopment = Meteor.settings.public.ENVIRONMENT === 'development'; // 3
//                                                                               // 4
//Settings.isProduction = Meteor.settings.public.ENVIRONMENT === 'production';   // 5
                                                                                 // 6
///////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.settings = {
  Settings: Settings
};

})();

//# sourceMappingURL=settings.js.map
