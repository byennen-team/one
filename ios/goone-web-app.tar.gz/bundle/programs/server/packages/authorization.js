(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var _ = Package.underscore._;
var Roles = Package['digilord:roles'].Roles;
var Settings = Package.settings.Settings;

/* Package-scope variables */
var HttpBasicAuth;

(function () {

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/authorization/basic_auth.js                                   //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
HttpBasicAuth = (function () {                                            // 1
  var HttpBasicAuth = function (callback, realm) {                        // 2
    this.callback = callback;                                             // 3
    this.realm = realm;                                                   // 4
  };                                                                      // 5
                                                                          // 6
  HttpBasicAuth.prototype = {                                             // 7
    constructor: HttpBasicAuth,                                           // 8
    protect: function (routes) {                                          // 9
      routes = routes || [''];                                            // 10
      if(!_.isArray(routes))                                              // 11
        throw new Error('"routes" must be an array of route Strings');    // 12
                                                                          // 13
      // Splice the middleware stack and slip in the auth function        // 14
      // so it is called first at desired routes (in specified order)     // 15
      for(var i = 0; i < routes.length; i++) {                            // 16
        WebApp.connectHandlers.stack.splice(i, 0, {                       // 17
          route: routes[i],                                               // 18
          handle: WebApp.__basicAuth__(this.callback, this.realm)         // 19
        });                                                               // 20
      }                                                                   // 21
    }                                                                     // 22
  };                                                                      // 23
                                                                          // 24
  return HttpBasicAuth;                                                   // 25
})();                                                                     // 26
                                                                          // 27
// Setup HTTP password for dev.gooneapp.com                               // 28
// if(Settings.isProduction) {                                            // 29
//  var basicAuth = new HttpBasicAuth('one', 'one');                      // 30
//  basicAuth.protect();                                                  // 31
// }                                                                      // 32
                                                                          // 33
////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/authorization/roles_server.js                                 //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
// On server startup, if the database is empty, create some initial data. // 1
// TODO: add roles on startup                                             // 2
if (Meteor.roles.find().count() === 0) {                                  // 3
    Roles.createRole('admin');                                            // 4
}                                                                         // 5
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.authorization = {};

})();

//# sourceMappingURL=authorization.js.map
