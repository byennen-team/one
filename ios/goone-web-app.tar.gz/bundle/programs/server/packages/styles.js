(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.styles = {};

})();

//# sourceMappingURL=styles.js.map
