(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RouteController = Package['iron:router'].RouteController;
var Route = Package['iron:router'].Route;
var Router = Package['iron:router'].Router;

/* Package-scope variables */
var Routes;

(function () {

//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// packages/routes/routes_enum.js                                               //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
                                                                                //
Routes = {                                                                      // 1
  DASHBOARD: 'dashboard',                                                       // 2
  LOGIN: 'login',                                                               // 3
  LOGOUT: 'logout',                                                             // 4
  PROFILE: 'profile',                                                           // 5
  COMPANY_APPS: 'company_apps',                                                 // 6
  LIBRARY: 'library'                                                            // 7
};                                                                              // 8
                                                                                // 9
Routes.Admin = {                                                                // 10
  COMPANIES: 'adminCompanies',                                                  // 11
  COMPANIES_NEW: 'adminCompaniesNew',                                           // 12
  DASHBOARD: 'adminDashboard',                                                  // 13
  USERS: 'adminUsers'                                                           // 14
};                                                                              // 15
                                                                                // 16
//////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// packages/routes/routes_map.js                                                //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
                                                                                //
/*****************************************************************************/ // 1
/* Client and Server Routes */                                                  // 2
/*****************************************************************************/ // 3
Router.configure({                                                              // 4
  layoutTemplate: 'application',                                                // 5
  loadingTemplate: 'loading',                                                   // 6
  notFoundTemplate: 'notFound'                                                  // 7
});                                                                             // 8
                                                                                // 9
Router.map(function () {                                                        // 10
  this.route(Routes.LOGIN, {                                                    // 11
    path: '/',                                                                  // 12
    layoutTemplate: 'loginLayout'                                               // 13
  });                                                                           // 14
                                                                                // 15
  this.route(Routes.LOGIN, {                                                    // 16
    path: '/home',                                                              // 17
    layoutTemplate: 'loginLayout'                                               // 18
  });                                                                           // 19
                                                                                // 20
  this.route(Routes.LOGOUT, {                                                   // 21
    path: '/logout',                                                            // 22
    action: function () {                                                       // 23
      Meteor.logout();                                                          // 24
      this.redirect(Routes.LOGIN);                                              // 25
    }                                                                           // 26
  });                                                                           // 27
                                                                                // 28
  this.route(Routes.COMPANY_APPS, {                                             // 29
    path: '/company-apps'                                                       // 30
  });                                                                           // 31
                                                                                // 32
  this.route(Routes.LIBRARY, {                                                  // 33
    path: '/library'                                                            // 34
  });                                                                           // 35
                                                                                // 36
  this.route(Routes.DASHBOARD, {                                                // 37
    path: '/dashboard'                                                          // 38
  });                                                                           // 39
                                                                                // 40
  this.route(Routes.PROFILE, {                                                  // 41
    path: '/profile'                                                            // 42
  });                                                                           // 43
                                                                                // 44
  /* Admin */                                                                   // 45
  this.route(Routes.Admin.DASHBOARD, {                                          // 46
    path: '/admin'                                                              // 47
  });                                                                           // 48
                                                                                // 49
  this.route(Routes.Admin.USERS, {                                              // 50
    path: '/admin/users'                                                        // 51
  });                                                                           // 52
                                                                                // 53
  this.route(Routes.Admin.COMPANIES, {                                          // 54
    path: '/admin/companies'                                                    // 55
  });                                                                           // 56
                                                                                // 57
  this.route(Routes.Admin.COMPANIES_NEW, {                                      // 58
    path: '/admin/companies/new'                                                // 59
  });                                                                           // 60
});                                                                             // 61
                                                                                // 62
//////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.routes = {};

})();

//# sourceMappingURL=routes.js.map
