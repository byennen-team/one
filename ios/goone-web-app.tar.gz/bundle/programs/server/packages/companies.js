(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Companies;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/companies/companies_common.js                            //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Companies = new Meteor.Collection('companies');                      // 1
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/companies/companies_server.js                            //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Companies.allow({                                                    // 1
  insert: function (userId, doc) {                                   // 2
    return true;                                                     // 3
  }                                                                  // 4
});                                                                  // 5
                                                                     // 6
Meteor.publish('companies', function () {                            // 7
  return Companies.find({});                                         // 8
});                                                                  // 9
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.companies = {
  Companies: Companies
};

})();

//# sourceMappingURL=companies.js.map
